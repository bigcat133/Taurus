#!/usr/bin/env python
# -*- coding: utf-8 -*-


class ParamError(Exception):
    pass


class DriverBuildError(Exception):
    pass
