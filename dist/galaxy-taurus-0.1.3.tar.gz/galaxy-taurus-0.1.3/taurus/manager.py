#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json

from cinderclient.v2 import client
from libcloud.compute.providers import get_driver
from libcloud.compute.types import Provider

# from libcloud.storage.types import Provider as storageProvider
# from libcloud.storage.providers import get_driver as storage_get_driver

# from libcloud.common.openstack_identity import OpenStackIdentity_3_0_Connection
from libcloud.common.openstack_identity import OpenStackIdentityTokenScope

from taurus.nsdrivers.drivers.openstack import NSOpenStackIdentityConnection
from taurus.exceptions import ParamError, DriverBuildError


test_func_list = {
    'openstack': 'list_sizes',
    'openstack_identity': 'authenticate',
    'openstack_cinder': 'authenticate',
    'aliyun': 'list_sizes',
    'ceph': 'get_cluster_stats'
}

providerList = ['openstack']


class DriverList:

    @staticmethod
    def getTenantName(args, timeout=10):
        return 'admin'
        user_id = getattr(args, 'user_id')
        key = getattr(args, 'key')
        auth_url = getattr(args, 'auth_url')

        driver = NSOpenStackIdentityConnection(
            auth_url=auth_url,
            user_id=user_id,
            key=key,
            token_scope=OpenStackIdentityTokenScope.UNSCOPED,
            timeout=timeout
        )
        driver.authenticate()
        resp = driver.authenticated_callApi('/v3/auth/tokens', 'GET')
        tokens = json.loads(resp.body)
        return tokens['token']['project']['name']

    @staticmethod
    def openstack(args, timeout=10):
        user_id = getattr(args, 'user_id')
        key = getattr(args, 'key')
        auth_url = getattr(args, 'auth_url')
        if not hasattr(args, 'tenant_name'):
            tenant_name = DriverList.getTenantName(args)
        else:
            tenant_name = args.tenant_name

        cls = get_driver(Provider.OPENSTACK)
        driver = cls(
            user_id, key,
            ex_force_auth_version='3.x_password',
            ex_force_auth_url=auth_url,
            ex_tenant_name=tenant_name,
            timeout=timeout
        )

        return driver

    @staticmethod
    def openstack_identity(args, timeout=10):
        user_id = getattr(args, 'user_id')
        key = getattr(args, 'key')
        auth_url = getattr(args, 'auth_url')
        # tenant_name = DriverList.getTenantName(args)

        driver = NSOpenStackIdentityConnection(
            auth_url=auth_url,
            user_id=user_id,
            key=key,
            # token_scope=OpenStackIdentityTokenScope.PROJECT,
            token_scope=OpenStackIdentityTokenScope.UNSCOPED,
            # tenant_name=tenant_name,
            timeout=timeout
        )

        return driver

    @staticmethod
    def openstack_customer(args, timeout=10):
        from taurus.nsdrivers.providers import Provider
        from taurus.nsdrivers.providers import get_driver

        user_id = getattr(args, 'user_id')
        key = getattr(args, 'key')
        auth_url = getattr(args, 'auth_url')
        if not hasattr(args, 'tenant_name'):
            tenant_name = DriverList.getTenantName(args)
        else:
            tenant_name = args.tenant_name

        cls = get_driver(Provider.OPENSTACK)
        driver = cls(user_id, key,
                     ex_force_auth_version='3.x_password',
                     ex_force_auth_url=auth_url,
                     ex_tenant_name=tenant_name,
                     timeout=timeout)

        return driver

    @staticmethod
    def openstack_cinder(args, timeout=10):
        user_id = getattr(args, 'user_id')
        key = getattr(args, 'key')
        auth_url = getattr(args, 'auth_url')
        if not hasattr(args, 'tenant_name'):
            tenant_name = DriverList.getTenantName(args)
        else:
            tenant_name = args.tenant_name

        id_driver = DriverBuilder.get(
            'openstack',
            {
                'user_id': user_id,
                'key': key,
                'auth_url': auth_url,
                'tenant_name': tenant_name
            },
            'identity'
        )
        id_driver.authenticate()
        projList = id_driver.list_projects()
        for proj in projList:
            if proj.name == tenant_name:
                tenant_id = proj.id
                break
        else:
            raise DriverBuildError('Tenant %s is not exist' % tenant_name)

        driver = client.Client(
            username=user_id,
            api_key=key,
            tenant_id=tenant_id,
            auth_url=auth_url + '/v3'
        )

        return driver

    @staticmethod
    def aliyun(args, timeout=15):
        user_id = getattr(args, 'user_id')
        key = getattr(args, 'key')
        region = getattr(args, 'region')

        cls = get_driver(Provider.ALI_ECS)
        driver = cls(user_id, key, region, timeout=timeout)

        return driver

    @staticmethod
    def ceph(args, timeout=10):
        """
        http://docs.ceph.com/docs/giant/rados/api/python/#installation
        """
        import rados

        auth_url = getattr(args, 'auth_url')
        if isinstance(auth_url, unicode):
            auth_url = str(auth_url)

        # cluster = rados.Rados(conffile='ceph.conf', conf=dict(keyring='ceph.client.admin.keyring'))
        cluster = rados.Rados()
        cluster.conf_set('mon_host', auth_url)
        cluster.connect(timeout)

        return cluster


class DriverBuilder:

    @staticmethod
    def get(driverName, args, subName=None, timeout=30, test_func=None):
        """
        Test driver config is ok
        params:
        driverName : driver name as openstack, aliyun
        args : build driver paramters
        if miss some paramter will raise AttributeError

        return : return a driver by building
        if don't find driver name return None
        """
        if not isinstance(args, dict):
            raise ParamError('The args is must dict')

        class paramlist:
            pass

        params = paramlist()
        for k in args:
            setattr(params, k, args[k])

        d_name = driverName.lower()

        if subName:
            d_name = '%s_%s' % (d_name, subName)

        if hasattr(DriverList, d_name):
            d_func = getattr(DriverList, d_name)
            driver = d_func(params, timeout)
            return driver
        else:
            raise DriverBuildError('Driver provider is not exist!!!')

    @staticmethod
    def test(driverName, args, subName=None):
        """
        build driver by driver name
        params:
        driverName : driver name as openstack, aliyun
        args : build driver paramters
        if miss some paramter will raise AttributeError

        return : return a driver by building
        if don't find driver name return None
        """

        try:
            driver = DriverBuilder.get(driverName, args, subName, timeout=5)
            d_name = driverName.lower()
            if subName:
                d_name = '%s_%s' % (d_name, subName)

            test_fun_name = test_func_list[d_name]
            test_func = getattr(driver, test_fun_name)
            test_func()
        except Exception as ex:
            return False, ex.message
        return True, ''
