#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

setup(
    name='galaxy-taurus',
    version='0.1.6',
    description='An adapter base libcloud',
    keywords='Adapter, libCloud, openstack',
    author='liming3',
    author_email='liming3@intra.nsfocus.com',
    license='Nsfocus License',
    packages=find_packages(),
    zip_safe=False,
    install_requires=[
        'backports.ssl-match-hostname==3.5.0.1',
        'apache-libcloud==1.5.0',
        'python-cinderclient==1.11.0',
        'keystoneauth1==2.18.0',
        'python-novaclient==8.0.0'
    ],
)
